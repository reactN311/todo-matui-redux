// export * from './store'
// export * as action from './action-creaters'

import {store} from './store';
export  {store};
// export  {persistor};